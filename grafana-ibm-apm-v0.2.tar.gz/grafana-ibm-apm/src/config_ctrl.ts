///<reference path="../typings/tsd.d.ts" />

import _ from 'lodash';

export class IPMConfigCtrl {
    static templateUrl = 'partials/config.html';
    current: any;

    /** @ngInject */
    constructor($scope) {
        this.current.jsonData = this.current.jsonData || {};
        this.current.jsonData.providerVersion = this.current.jsonData.providerVersion || '8x';
    }

    providerVersions = [
        { name: 'v8.x', value: '8x' },
        { name: 'v6.x', value: '6x' }

    ];

}