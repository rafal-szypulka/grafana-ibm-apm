///<reference path="../typings/tsd.d.ts" />
import moment from 'moment';
import _ from 'lodash';

class IPMDatasource {
  name: string;
  url: string;
  providerVersion: string;
  appId: any;
  pk: any;

  /** @ngInject */
  constructor(instanceSettings, private $q, private backendSrv, private templateSrv) {
    this.name = instanceSettings.name;
    this.backendSrv = backendSrv;
    this.url = instanceSettings.url;
    this.name = instanceSettings.name;
    this.providerVersion = instanceSettings.jsonData.providerVersion;
  }

  query(options) {
    if (this.providerVersion === '8x') {
      var rangeFrom = moment(options.range.from).utc().format('YYYYMMDDTHHmmss');
      var rangeTo = moment(options.range.to).utc().format('YYYYMMDDTHHmmss');
    } else {
      var rangeFrom = moment(options.range.from).format('YYYYMMDDTHHmmss');
      var rangeTo = moment(options.range.to).format('YYYYMMDDTHHmmss');
    }
    var requests = _.map(options.targets, target => {
      return {
        url: this.url + '/datasources/' + encodeURIComponent(target.target) + '/datasets/' + target.AttributeGroup + '/items',
        alias: this.templateSrv.replace(target.alias),
        valueAttribute: target.valueAttribute,
        params: {
          param_SourceToken: this.templateSrv.replace(target.AgentInstance),
          clearCache: 'true',
          optimize: 'true',
          //param_Time: '-P0Y0M0DT4H0M0S',
          // param_Time: moment(options.range.from).utc().format('YYYYMMDDTHHmmss') + '--' + moment(options.range.to).utc().format('YYYYMMDDTHHmmss'),
          param_Time: rangeFrom + '--' + rangeTo,
          param_NoCache: 'false',
          properties: target.Attribute + ',' + target.timeAttribute + ',' + (target.PrimaryKey || ''),
          condition: target.Condition,
          //   param_tz: 'UTC'
        }
      };
    });

    // delete condition parameter if empty because it throws an exception when empty :/
    requests.forEach(function (request) {
      if (request.params.condition === '') {
        delete request.params.condition;
      }
    });
    return this.makeMultipleRequests(requests);
  }

  getAgentTypes() {
    var self = this;
    let request = {
      url: self.url + '/datasources'
    };

    return this.makeRequest(request)
      .then(result => {
        if (result.response.items) {
          return result.response.items;
        } else {
          return [];
        }
      });
  }

  getAttributeGroups(agentType) {
    var self = this;
    let request = {
      url: self.url + '/datasources/' + encodeURIComponent(agentType) + '/datasets'
    };

    return this.makeRequest(request)
      .then(result => {
        if (result.response.items) {
          return result.response.items;
        } else {
          return [];
        }
      });
  }


  // Previously getAgentInstances(agentType)
  metricFindQuery(options) {
    var self = this;
    var agents = []
    var target = typeof (options) === "string" ? options : options.target;
    let request = {
      url: self.url + '/datasources/' + encodeURIComponent(target) + '/datasets/msys/items?properties=all'
    };

    return this.makeRequest(request)
      .then(result => {
        if (result.response.items) {
          result.response.items.forEach(function (item) {
            if (item.properties) {
              item.properties.forEach(function (property) {
                if (property.id === 'ORIGINNODE') {
                  agents.push({ text: property.value, value: property.value });
                }
              });
            }
          });
          //console.log(agents);
          return agents;
        } else {
          return [];
        }
      });
  }


  getAttributes(agentType, attributeGroup) {
    var self = this;
    var aG = attributeGroup.replace(/^.*-->  /, '');
    let request = {
      url: self.url + '/datasources/' + encodeURIComponent(agentType) + '/datasets/' + encodeURIComponent(aG) + '/columns'
    };

    return this.makeRequest(request)
      .then(result => {
        if (result.response.items) {
          return result.response.items;
        } else {
          return [];
        }
      });
  }

  getPrimaryKey(agentType, attributeGroup) {
    var self = this;
    var ids = [];
    let request = {
      url: self.url + '/datasources/' + encodeURIComponent(agentType) + '/datasets/' + encodeURIComponent(attributeGroup) + '/columns'
    };
    return this.makeRequest(request)
      .then(result => {
        var items = result.response.items;
        items.forEach(function (item) {
          if (item.primaryKey) {
            ids.push({ id: item.id, label: item.label });
          }
        });
        return ids;
      });
  }


  testDatasource() {
    var self = this;
    return this.makeRequest({ url: self.url }).then(() => {
      return { status: "success", message: "Data source is working", title: "Success" };
    });
  }

  _parseMetricResults(results) {
    var self = this;
    var targetData = [];
    var items = results.response.items;
    if (items.length > 0) {
      console.log(results);
      items.forEach(item => {
        item.alias = results.alias;
        item.valueAttribute = results.valueAttribute;
      });

      if (typeof items[0].properties[2] !== 'undefined') {
        items.forEach(function (item) {
          targetData.push(item.properties[2].value);
        });
        //list of item instances like CPUID
        var targets = targetData.reduce(function (a, b) {
          if (a.indexOf(b) < 0) a.push(b);
          return a;
        }, []);

        var seriesList = [];
        targets.forEach(function (target) {
          seriesList.push({
            target: self._parseTargetAlias(items, target),
            datapoints: self._getTargetSeries(items, target)
          })
        });
      } else {
        var seriesList = [];
        seriesList.push({
          target: self._parseTargetAlias(items, null),
          datapoints: self._getTargetSeries(items, null)
        })
      }
    } else {
      var seriesList = [];
      seriesList.push({

        target: '',
        datapoints: []
      })
    }
    return seriesList;
  }

  _getTargetSeries(items, target) {
    var series = [];

    if (target || target == 0) {
      items.forEach(function (item) {
        if (item.properties[2].value == target) {
          series.push([parseFloat(item.properties[0][item.valueAttribute]), moment(item.properties[1].value).valueOf()]);
        }
      });
    } else {
      items.forEach(function (item) {
        series.push([parseFloat(item.properties[0][item.valueAttribute]), moment(item.properties[1].value).valueOf()]);
      });
    }
    return series;
  }

  _parseTargetAlias(items, value) {
    if (value || value == 0) {
      if (items[0].alias) {
        return items[0].alias + ":" + value;
      } else {
        return items[0].properties[0].id + ":" + value;
      }
    } else {
      return items[0].properties[0].id;
    }
  }

  makeMultipleRequests(requests) {
    var self = this;
    return this.$q(function (resolve, reject) {
      var mergedResults = {
        data: []
      };
      var promises = [];
      requests.forEach(function (request) {
        promises.push(self.makeRequest(request));
      });
      self.$q.all(promises).then((data) => {
        data.forEach(function (result) {
          mergedResults.data = mergedResults.data.concat(self._parseMetricResults(result));
        });
        resolve(mergedResults);
      });
    });
  }


  makeRequest(request) {
    var options: any = {
      method: "get",
      url: request.url,
      params: request.params,
      data: request.data,
    };

    return this.backendSrv.datasourceRequest(options).then(result => {
      return { response: result.data, alias: request.alias, valueAttribute: request.valueAttribute };
    }, function (err) {
      if (err.status !== 0 || err.status >= 300) {
        if (err.data && err.data.error) {
          throw { message: 'IPM Error Response: ' + err.data.error.title, data: err.data, config: err.config };
        } else {
          throw { message: 'IPM Error: ' + err.message, data: err.data, config: err.config };
        }
      }
    });
  }

}

export { IPMDatasource };
